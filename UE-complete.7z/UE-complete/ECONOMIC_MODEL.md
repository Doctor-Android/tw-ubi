# TW-UBI Economic Model

**How the system works economically**

---

## The Two-Token System

TW-UBI uses two separate tokens with different economic roles:

### 🟢 UE (Universal Entitlement) - Income Token

**Purpose**: Monthly income for everyone

**Characteristics**:
- **Fixed issuance**: 696 UE per person per epoch (30 days)
- **Same for everyone**: No variation, no means testing
- **Designed to be spent**: Not for long-term saving
- **Does NOT decay**: Your UE balance never decreases
- **Can convert to BU**: But conversion power decays over time

**Economic Role**: Flow of income, not store of value

### 🟣 BU (Base Unit) - Reserve Token

**Purpose**: Long-term savings and system credibility

**Characteristics**:
- **Fixed supply**: 1,000,000 BU total (set at genesis)
- **Scarce**: Limited quantity, no new minting
- **Does NOT decay**: Stable store of value
- **Not distributed as income**: Only obtained via conversion
- **Held in treasury**: Most BU reserved for conversions

**Economic Role**: Store of value, system backing

---

## How Income Works

### Monthly Issuance

Every 30 days (one epoch), every verified person can claim:

```
696 UE per epoch
```

**Key points**:
- Same amount for everyone
- No applications or approval needed
- Automatic and predictable
- Frozen at deployment (cannot change without hard fork)

### Example Timeline

```
Epoch 0: Person A claims → 696 UE
Epoch 1: Person A claims → 696 UE (total: 1,392 UE)
Epoch 2: Person A claims → 696 UE (total: 2,088 UE)
...
```

**Income accumulates** - you can claim each epoch, and your UE balance grows.

---

## How Conversion Works

### UE → BU Conversion

You can convert UE to BU, but the **conversion rate decays over time**.

**Formula**:
```
BU received = UE amount × rateIndex
```

Where `rateIndex` starts at 1.0 and decreases each epoch.

### Conversion Rate Decay

| Time | Rate Index | 100 UE converts to |
|------|------------|-------------------|
| Epoch 0 | 1.00 | 100 BU |
| Epoch 1 | 0.99 | 99 BU |
| Epoch 2 | 0.98 | 98 BU |
| Epoch 10 | 0.90 | 90 BU |
| Epoch 20 | 0.82 | 82 BU |
| Epoch 50 | 0.61 | 61 BU |

**The longer you wait, the less BU you get per UE.**

### Conversion Constraints

1. **Per-epoch cap**: Max 1,000 UE per person per epoch
2. **Delay**: 1 epoch delay before BU is unlocked
3. **Fee**: 0.5% conversion fee
4. **Slippage protection**: You set minimum BU out

**Example conversion**:
```
You have: 1,000 UE
Current rate: 0.95 BU/UE
Fee: 0.5% = 5 UE
After fee: 995 UE
BU received: 995 × 0.95 = 945.25 BU
Unlocks: Next epoch
```

---

## Why Hoarding Doesn't Work

### The Economic Incentive

**If you hoard UE**:
- Your UE balance stays the same (doesn't decay)
- But conversion power decreases over time
- Waiting costs you BU

**If you convert early**:
- You get more BU per UE
- You can save in BU (stable value)
- You're rewarded for converting sooner

**If you spend UE**:
- You use it for living expenses
- No conversion needed
- Income serves its purpose

### Mathematical Example

**Scenario**: You receive 696 UE each epoch

**Option 1: Hoard for 10 epochs**
```
Total UE: 6,960 UE
Rate after 10 epochs: 0.90 BU/UE
BU received: 6,264 BU
```

**Option 2: Convert each epoch**
```
Epoch 0: 696 UE × 1.00 = 696 BU
Epoch 1: 696 UE × 0.99 = 689 BU
Epoch 2: 696 UE × 0.98 = 682 BU
...
Epoch 9: 696 UE × 0.91 = 633 BU
Total BU: ~6,500 BU
```

**Converting early gives you ~236 more BU** (about 3.8% more)

### The Incentive Structure

1. **Spend now**: Use income for living (no penalty)
2. **Convert early**: Get more BU (rewarded)
3. **Hoard**: Lose conversion power (penalized by time)

**Time makes hoarding irrational.**

---

## Decay Rate Mechanism

### How Decay Adjusts

The decay rate adjusts based on **survival basket inflation**:

```
decayRate = baseDecay - (k × inflation)

Where:
  baseDecay = 1% per epoch (fixed)
  k = 0.5 (sensitivity parameter)
  inflation = survival basket inflation rate
```

### Example Adjustments

**Low inflation (0%)**:
```
decayRate = 0.01 - (0.5 × 0) = 0.01 (1% per epoch)
```

**High inflation (2%)**:
```
decayRate = 0.01 - (0.5 × 0.02) = 0.00 (0% decay)
```

**Very high inflation (4%)**:
```
decayRate = 0.01 - (0.5 × 0.04) = -0.01
→ Clamped to minimum: 0.005 (0.5% per epoch)
```

### Why This Matters

- **High inflation**: Decay slows → conversion power lasts longer
- **Low inflation**: Decay normal → conversion power decreases normally
- **System adapts**: But always within bounds (0.5% to 2% per epoch)

---

## Treasury and Reserves

### BU Reserve

**Initial supply**: 1,000,000 BU

**Held in treasury**: Most BU is reserved for:
- UE → BU conversions
- System credibility
- Long-term backing

**Not distributed as income**: BU is never given directly as UBI.

### Treasury Flow

```
Treasury BU → Conversions → User BU balances
```

**One-way flow**: BU moves from treasury to users via conversion, not back.

### Economic Stability

- **Fixed BU supply**: No inflation of reserve token
- **Fixed UE issuance**: Predictable income
- **Decay mechanism**: Prevents hoarding
- **Treasury backing**: System has reserves

---

## Economic Flow Diagram

```
┌─────────────────────────────────────────┐
│         TW-UBI Economic System          │
└─────────────────────────────────────────┘

EVERY EPOCH (30 days):
┌─────────────────────────────────────────┐
│  Each Person Claims → 696 UE            │
│  (Income accumulates)                   │
└─────────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │  User Has UE Balance │
    └─────────────────────┘
              │
    ┌─────────┴─────────┐
    │                   │
    ▼                   ▼
┌─────────┐      ┌──────────────┐
│  SPEND  │      │   CONVERT      │
│   UE    │      │  UE → BU       │
└─────────┘      └──────────────┘
                        │
                        ▼
              ┌─────────────────┐
              │  Rate Decays    │
              │  Over Time      │
              └─────────────────┘
                        │
                        ▼
              ┌─────────────────┐
              │  Treasury BU    │
              │  → User BU       │
              └─────────────────┘
```

---

## Key Economic Principles

### 1. Income ≠ Wealth

- **UE (Income)**: Flow, designed to be spent
- **BU (Wealth)**: Stock, designed to be saved

### 2. Time Has Value

- Converting early = more BU
- Hoarding = less BU over time
- Spending = no penalty

### 3. Predictable Rules

- Fixed income amount
- Fixed decay bounds
- No discretionary changes
- No governance voting

### 4. Anti-Hoarding Design

- Decay makes hoarding costly
- Early conversion rewarded
- Spending encouraged

### 5. System Stability

- Fixed BU supply (no inflation)
- Fixed UE issuance (predictable)
- Treasury backing (credibility)
- Decay bounds (safety)

---

## Economic Scenarios

### Scenario 1: Regular Spender

**Behavior**: Claims UE, spends most of it

**Economics**:
- Receives 696 UE per epoch
- Spends 500-600 UE per epoch
- Small UE balance accumulates
- No conversion needed

**Result**: Income serves its purpose (living expenses)

### Scenario 2: Early Converter

**Behavior**: Claims UE, converts to BU immediately

**Economics**:
- Receives 696 UE per epoch
- Converts at rate ~1.0 BU/UE
- Gets ~690 BU per epoch
- Saves in BU (stable value)

**Result**: Maximizes BU accumulation, rewarded for early conversion

### Scenario 3: Hoarder

**Behavior**: Claims UE, hoards for many epochs

**Economics**:
- Receives 696 UE per epoch
- Hoards for 10 epochs = 6,960 UE
- Converts at rate ~0.90 BU/UE
- Gets ~6,264 BU total

**Result**: Loses ~236 BU compared to early conversion (3.8% penalty)

### Scenario 4: Mixed Strategy

**Behavior**: Claims UE, spends some, converts some

**Economics**:
- Receives 696 UE per epoch
- Spends 400 UE (living)
- Converts 296 UE to BU
- Balances spending and saving

**Result**: Optimal for most users (living + saving)

---

## Economic Guarantees

### What's Guaranteed

1. ✅ **Fixed income**: 696 UE per epoch, same for everyone
2. ✅ **No inflation**: BU supply fixed, UE issuance fixed
3. ✅ **Decay bounds**: Rate always between 0.5% and 2% per epoch
4. ✅ **Conversion available**: Always can convert UE → BU
5. ✅ **Treasury backing**: BU reserves for conversions

### What's NOT Guaranteed

1. ❌ **BU price**: BU price floats (not pegged)
2. ❌ **UE value**: UE value depends on conversion rate
3. ❌ **Conversion rate**: Decays over time (by design)
4. ❌ **Returns**: Not an investment, no promised returns

---

## Summary

**TW-UBI economics in one sentence**:

*Everyone gets the same monthly income (UE), but time makes hoarding it irrational because conversion power decays, encouraging spending or early conversion to savings (BU).*

**Key insight**:

Income is for living. Wealth is for saving. TW-UBI enforces this by making time the cost of hoarding income.

---

**Not an investment.**
**Not a DAO.**
**Just income — by rule, not permission.**

