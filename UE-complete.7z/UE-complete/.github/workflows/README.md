# GitHub Actions Workflows

This directory contains GitHub Actions workflows for automated testing and CI/CD.

## Workflows

### `test.yml`
Comprehensive test suite that runs on push and pull requests:
- **Backend Tests**: Rust backend with PostgreSQL
- **Frontend Tests**: React frontend build verification
- **Identity Adapters**: JavaScript adapter tests
- **Linting**: Code quality checks

### `ci.yml`
Full CI pipeline for main branch:
- All tests from `test.yml`
- Release builds
- Production-ready checks

### `rust.yml`
Rust-specific workflow:
- Format checking
- Clippy linting
- Full test suite
- Database integration tests

## Running Tests Locally

### Backend
```bash
cd backend
export DATABASE_URL="postgresql://postgres:postgres@localhost/ubi_test"
psql $DATABASE_URL -f migrations/001_initial_schema.sql
cargo test
```

### Frontend
```bash
cd frontend
npm install
npm run build
```

### Identity Adapters
```bash
cd identity-adapters
node test.js
```

## Requirements

- PostgreSQL 15+ (for backend tests)
- Rust stable (for backend)
- Node.js 18+ (for frontend and adapters)

