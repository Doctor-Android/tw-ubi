# Forking and UE Amount Changes

**Can forks change the amount of UBI (UE) given?**

---

## Short Answer

**Yes, forks can change the UE amount.** 

Forking means creating a new system with new rules. A fork can set any UE amount it wants.

However, **this breaks compatibility** with the original system and creates a **separate system**.

---

## How UE Amount is Set

### In the Code

The UE amount is defined as a **constant**:

```rust
// backend/src/constants.rs
pub const UE_MINT_PER_EPOCH: &str = "696000000000000000000"; // 696 UE
```

This constant is used when claiming UBI:

```rust
// backend/src/services/ubi.rs
let ubi_amount = UE_MINT_PER_EPOCH.to_string(); // Fixed: 696 UE
```

### Current Implementation

- **Amount**: 696 UE per epoch
- **Frozen**: Set at deployment
- **Same for everyone**: No variation
- **Constitutional**: Part of the base rules

---

## What Forking Means

### Fork = New System

When you fork TW-UBI, you create:

1. **New codebase**: Copy of the code
2. **New rules**: Can change any rules
3. **New state**: Separate database/blockchain
4. **New identity**: Separate from original

**A fork is a new system, not a modification of the original.**

### What Can Be Changed in a Fork

**Everything can be changed**:

✅ UE amount (696 → any number)
✅ Decay rates
✅ Conversion caps
✅ Epoch length
✅ Identity requirements
✅ Any other rules

**A fork has complete freedom to change anything.**

---

## Examples of Fork Changes

### Example 1: Higher UE Amount

**Original**: 696 UE per epoch
**Fork**: 1000 UE per epoch

**Changes needed**:
```rust
// In the fork's constants.rs
pub const UE_MINT_PER_EPOCH: &str = "1000000000000000000000"; // 1000 UE
```

**Result**: Fork gives more income, but is a separate system.

### Example 2: Lower UE Amount

**Original**: 696 UE per epoch
**Fork**: 500 UE per epoch

**Changes needed**:
```rust
pub const UE_MINT_PER_EPOCH: &str = "500000000000000000000"; // 500 UE
```

**Result**: Fork gives less income, but is a separate system.

### Example 3: Variable UE Amount

**Original**: Fixed 696 UE
**Fork**: Variable based on region/cost of living

**Changes needed**:
- Remove constant
- Add calculation logic
- Modify UBI service

**Result**: Fork has different economics, separate system.

---

## Compatibility and Migration

### Are Forks Compatible?

**No, forks are NOT compatible**:

- Different UE amounts
- Different rules
- Separate state
- Separate identity

**You can't migrate between forks** without:
- Losing your original UE balance
- Starting fresh in the fork
- Re-registering identity

### Can You Use Both?

**Yes, but separately**:

- Original system: 696 UE per epoch
- Fork system: Different amount per epoch
- Different wallets
- Different identities
- No connection between them

**They are separate systems.**

---

## Constitutional Perspective

### Original System Rules

**In the original TW-UBI**:

1. UE amount is **frozen at deployment**
2. Changing it requires a **hard fork**
3. Hard fork = new system, not modification

**The original system's rules cannot be changed without forking.**

### Fork Rules

**In a fork**:

1. Fork can set **any UE amount**
2. Fork can have **any rules**
3. Fork is **independent** of original

**A fork is free to change anything.**

---

## Why Forks Can Change UE Amount

### Technical Freedom

**Forking means**:
- Copy the code
- Modify constants
- Deploy new system
- Set your own rules

**No technical restrictions prevent changing UE amount.**

### Design Philosophy

**TW-UBI encourages forking**:

- Disagreement is expected
- Exit is healthier than governance
- Forks are a feature, not a bug

**If you want different UE amounts, fork and set your own.**

---

## Practical Considerations

### If You Fork with Different UE Amount

**What happens**:

1. **New system**: Separate from original
2. **New users**: Must register in fork
3. **New state**: No connection to original
4. **New economics**: Your rules, your amount

**Example**:
- Original: 696 UE per epoch, 10,000 users
- Fork: 1000 UE per epoch, 0 users (starts fresh)

### Migration Scenarios

**Scenario 1: User wants to switch**

- Leave original system
- Register in fork
- Start fresh (no balance transfer)
- Get fork's UE amount

**Scenario 2: Community forks**

- Group creates fork
- Sets their preferred UE amount
- Invites others to join
- Separate from original

**Scenario 3: Regional fork**

- Region wants different amount
- Forks with regional rules
- Regional identity requirements
- Regional UE amount

---

## Code Changes Required

### To Change UE Amount in a Fork

**Step 1: Modify constant**

```rust
// backend/src/constants.rs
// Original:
pub const UE_MINT_PER_EPOCH: &str = "696000000000000000000";

// Fork (example: 1000 UE):
pub const UE_MINT_PER_EPOCH: &str = "1000000000000000000000";
```

**Step 2: Update documentation**

- Update README
- Update economic model docs
- Update any references to 696 UE

**Step 3: Deploy**

- Deploy fork with new amount
- Users register in fork
- Fork operates independently

**That's it** - no other code changes needed for basic amount change.

---

## Economic Implications

### Higher UE Amount Fork

**If fork gives more UE** (e.g., 1000 vs 696):

- More income per person
- Higher total UE issuance
- May need more BU reserves
- Different economic dynamics

**Trade-offs**: More generous, but may be unsustainable.

### Lower UE Amount Fork

**If fork gives less UE** (e.g., 500 vs 696):

- Less income per person
- Lower total UE issuance
- Lower BU reserve needs
- More conservative economics

**Trade-offs**: More sustainable, but less generous.

### Variable UE Amount Fork

**If fork has variable amounts**:

- Different amounts for different people/regions
- More complex economics
- Breaks "same for everyone" principle
- May require means testing

**Trade-offs**: More flexible, but breaks core principle.

---

## Design Philosophy

### Original System

**TW-UBI original**:
- Fixed 696 UE per epoch
- Same for everyone
- Frozen at deployment
- Constitutional invariant

**Changing this requires a hard fork** (new system).

### Fork Philosophy

**TW-UBI encourages forking**:

> "If you want different income levels, different decay rules, different identity assumptions, different philosophy — Please fork this project."

**Forks are expected and encouraged.**

---

## Key Takeaways

1. **Yes, forks can change UE amount** - Complete freedom
2. **Fork = new system** - Not compatible with original
3. **No migration** - Can't transfer balances between forks
4. **Technical freedom** - Just change the constant
5. **Design philosophy** - Forks are encouraged
6. **Original rules frozen** - Can't change without forking

---

## Summary

**Can forks change the UE amount?**

**Yes.** A fork can set any UE amount it wants. It's a new system with new rules.

**Does this affect the original?**

**No.** The original system's rules remain frozen. Forks are separate systems.

**Is this encouraged?**

**Yes.** TW-UBI's design philosophy encourages forking for different rules, amounts, and philosophies.

---

**Forking is a feature, not a bug.**

**If you want different UE amounts, fork and set your own.**

