# TW-UBI Setup Guide

Complete setup instructions for the TW-UBI system.

## Prerequisites

- Rust (latest stable)
- Node.js 18+ and npm
- PostgreSQL 12+
- Git

## Step 1: Database Setup

```bash
# Install PostgreSQL (if not installed)
sudo apt install postgresql postgresql-contrib

# Create database
sudo -u postgres createdb ubi

# Run migrations
psql ubi < backend/migrations/001_initial_schema.sql
```

## Step 2: Backend Setup

```bash
cd backend

# Copy environment file
cp .env.example .env

# Edit .env with your settings:
# DATABASE_URL=postgresql://postgres:postgres@localhost/ubi
# HOST=127.0.0.1
# PORT=8080
# JWT_SECRET=your-secret-key-here
# MFA_ISSUER=TW-UBI
# GLOBAL_SALT=your-global-salt-here
# GENESIS_TIMESTAMP=0  # Or set to current timestamp

# Install dependencies and run
cargo build
cargo run
```

Backend will start on `http://127.0.0.1:8080`

## Step 3: Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Run development server
npm run dev
```

Frontend will start on `http://localhost:5173` (or similar)

## Step 4: Test Identity Adapters

```bash
cd identity-adapters

# Test adapters
node test.js
```

## Step 5: Verify System

1. **Health Check**
   ```bash
   curl http://localhost:8080/health
   ```

2. **Register a User** (using identity adapter)
   ```bash
   # Compute personId (example with Spain adapter)
   node -e "const spain = require('./identity-adapters/spain'); console.log(spain.computePersonId('12345678A', 'your-global-salt'))"
   
   # Register via API
   curl -X POST http://localhost:8080/api/users/register \
     -H "Content-Type: application/json" \
     -d '{
       "person_id": "computed-person-id-hex",
       "wallet_address": "0x1234...",
       "region_id": 1,
       "expiry_epoch": 100,
       "attestation_sig": "signature"
     }'
   ```

3. **Claim UBI**
   ```bash
   curl -X POST http://localhost:8080/api/ubi/claim \
     -H "X-Wallet-Address: 0x1234..."
   ```

4. **View Balances**
   ```bash
   curl http://localhost:8080/api/balances/ue \
     -H "X-Wallet-Address: 0x1234..."
   ```

## Frontend Usage

1. Open `http://localhost:5173` in browser
2. Enter wallet address
3. Click "User Mode" or "Admin Mode"
4. Use the dashboard to:
   - Claim UBI
   - Convert UE → BU
   - View balances
   - Export state (admin)

## Troubleshooting

### Database Connection Error
- Check PostgreSQL is running: `sudo systemctl status postgresql`
- Verify DATABASE_URL in `.env`
- Check database exists: `psql -l | grep ubi`

### Backend Compilation Error
- Update Rust: `rustup update`
- Clean build: `cargo clean && cargo build`

### Frontend Build Error
- Clear cache: `rm -rf node_modules package-lock.json && npm install`
- Check Node version: `node --version` (should be 18+)

### API Errors
- Check backend logs
- Verify CORS settings (if accessing from different origin)
- Check wallet address format

## Production Deployment

1. **Backend**
   - Use production database
   - Set strong JWT_SECRET and GLOBAL_SALT
   - Use reverse proxy (nginx)
   - Enable HTTPS

2. **Frontend**
   - Build: `npm run build`
   - Serve static files (nginx, CDN)
   - Update API_URL in code

3. **Security**
   - Never commit `.env` files
   - Use strong secrets
   - Enable rate limiting
   - Use HTTPS everywhere

## Next Steps

- Add authentication (JWT tokens)
- Implement rate limiting
- Add monitoring/logging
- Set up backups
- Configure production database

---

**System is ready for testing!**

